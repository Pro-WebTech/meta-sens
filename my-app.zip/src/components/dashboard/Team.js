import '../../assets/css/dashboard/Team.css'

function Team () {
  return(
    <div id="team" className="team-content">
      <p className="md-description">- Team</p>
      <p className="lg-description">Our <span style={{color:'#00E4D1'}}>Teams</span></p>
      <div className="row" style={{marginTop:'30px'}}>
        <div className="character-part">
          <div className="photo-part">

          </div>
          <p className="md-description1">Member Name Here</p>
          <p className="sm-description-team">Lorem ipsum dolor sit amadipiscing elit. Vitae at fringilla nulla.</p>
        </div>
        <div className="character-part">
          <div className="photo-part">

          </div>
          <p className="md-description1">Member Name Here</p>
          <p className="sm-description-team">Lorem ipsum dolor sit amadipiscing elit. Vitae at fringilla nulla.</p>
        </div>
        <div className="character-part">
          <div className="photo-part">

          </div>
          <p className="md-description1">Member Name Here</p>
          <p className="sm-description-team">Lorem ipsum dolor sit amadipiscing elit. Vitae at fringilla nulla.</p>
        </div>
      </div>
    </div>
  )
}

export default Team;